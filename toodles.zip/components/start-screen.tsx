"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { useSound } from "@/hooks/use-sound"

interface StartScreenProps {
  onStart: () => void
}

export default function StartScreen({ onStart }: StartScreenProps) {
  const [isLoading, setIsLoading] = useState(true)
  const { playSound } = useSound()

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 1500)
    return () => clearTimeout(timer)
  }, [])

  const handleStart = () => {
    playSound("chaching")
    onStart()
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center p-4">
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5, type: "spring" }}
        className="mb-8 text-center"
      >
        <motion.h1
          className="mb-2 text-7xl font-extrabold tracking-tight"
          style={{
            background: "linear-gradient(to right, #ff0080, #ff8c00, #ffed00, #00ff80, #00bfff, #8a2be2)",
            backgroundSize: "200% auto",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            textShadow: "0 0 10px rgba(255,255,255,0.3)",
          }}
          animate={{
            backgroundPosition: ["0% center", "200% center"],
          }}
          transition={{ duration: 10, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
        >
          TOODLES
        </motion.h1>
        <motion.p
          className="text-2xl font-bold text-gray-700"
          animate={{
            y: [0, -10, 0],
          }}
          transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
        >
          SAT Trivia Battle 🚀🎉
        </motion.p>
      </motion.div>

      <motion.div
        className="mb-12 flex justify-center"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <img
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/lol-IQo4MpSj8drtO1ntMtmQPHM38n2gUC.png"
          alt="Toodles Logo"
          className="h-48 w-48 rounded-full"
        />
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }}>
        <Button
          onClick={handleStart}
          disabled={isLoading}
          className="relative overflow-hidden px-8 py-6 text-xl font-bold text-white shadow-lg transition-all hover:scale-105 hover:shadow-xl"
          style={{
            background: "linear-gradient(to right, #ff0080, #ff8c00, #ffed00, #00ff80, #00bfff, #8a2be2)",
            backgroundSize: "200% auto",
            boxShadow: "0 0 5px rgba(102,51,153,0.5), 0 0 10px rgba(138,43,226,0.5)",
          }}
        >
          {isLoading ? "Loading..." : "START THE MADNESS!"}
          <motion.div
            className="absolute inset-0 -z-10"
            animate={{
              backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"],
            }}
            transition={{
              duration: 3,
              ease: "linear",
              repeat: Number.POSITIVE_INFINITY,
            }}
            style={{
              background: "linear-gradient(to right, #ff0080, #ff8c00, #ffed00, #00ff80, #00bfff, #8a2be2)",
              backgroundSize: "200% auto",
            }}
          />
        </Button>
      </motion.div>

      <motion.div
        className="mt-16 text-center text-sm text-gray-600"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
      >
        Created with 🧠 by Adhyaay Karnwal
      </motion.div>
    </div>
  )
}

