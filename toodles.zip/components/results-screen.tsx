"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { useGame } from "@/context/game-context"
import { useSound } from "@/hooks/use-sound"
import ConfettiExplosion from "react-confetti-explosion"

interface ResultsScreenProps {
  onRestart: () => void
}

export default function ResultsScreen({ onRestart }: ResultsScreenProps) {
  const { players, gameResults, resetGame } = useGame()
  const { playSound } = useSound()
  const [showConfetti, setShowConfetti] = useState(false)
  const [showCertificate, setShowCertificate] = useState(false)
  const [selectedRound, setSelectedRound] = useState<number | null>(null)

  const winner = gameResults.winner === "player1" ? players.player1 : players.player2
  const loser = gameResults.winner === "player1" ? players.player2 : players.player1

  useEffect(() => {
    // Play victory sounds
    playSound("cheer")

    // Show confetti after a delay
    const timer = setTimeout(() => {
      setShowConfetti(true)
    }, 500)

    // Show certificate after a delay
    const certificateTimer = setTimeout(() => {
      setShowCertificate(true)
    }, 2000)

    return () => {
      clearTimeout(timer)
      clearTimeout(certificateTimer)
    }
  }, [])

  const handleRestart = () => {
    resetGame()
    onRestart()
  }

  const getAvatarEmoji = (avatarId: string) => {
    switch (avatarId) {
      case "taco":
        return "🌮"
      case "pineapple":
        return "🍍"
      case "wizard":
        return "🧙"
      case "pencil":
        return "✏️"
      default:
        return "👽"
    }
  }

  const getTimeDifferenceText = () => {
    const scoreDiff = Math.abs(players.player1.score - players.player2.score)

    if (scoreDiff > 200) return "You were faster than lightning! ⚡"
    if (scoreDiff > 100) return "You crushed it like a math genius! 🧠"
    if (scoreDiff > 50) return "You were quicker than a calculator! 🔢"
    if (scoreDiff > 20) return "Not bad, not bad at all! 👍"
    return "You were slower than a sloth on melatonin! 😴"
  }

  // Rainbow border style
  const rainbowBorderStyle = {
    borderImage: "linear-gradient(45deg, #ff0080, #ff8c00, #ffed00, #00ff80, #00bfff, #8a2be2) 1",
    borderImageSlice: 1,
  }

  return (
    <div className="container mx-auto flex min-h-screen flex-col items-center justify-center p-4">
      <motion.h1
        className="mb-8 text-center text-5xl font-extrabold tracking-tight text-gray-800"
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
        style={{
          textShadow: "0 0 5px rgba(236,72,153,0.5), 0 0 10px rgba(249,115,22,0.5)",
        }}
      >
        Game Results!
      </motion.h1>

      {showConfetti && <ConfettiExplosion force={0.8} duration={3000} particleCount={100} width={1600} />}

      <div className="mb-8 grid w-full max-w-4xl gap-8 md:grid-cols-2">
        {/* Winner */}
        <motion.div
          className="relative rounded-xl border-4 bg-white p-6 shadow-lg"
          initial={{ opacity: 0, x: -50, scale: 0.8 }}
          animate={{ opacity: 1, x: 0, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          style={{
            boxShadow: "0 0 10px rgba(255,0,128,0.4), 0 0 20px rgba(255,140,0,0.3), 0 0 30px rgba(255,237,0,0.2)",
            ...rainbowBorderStyle,
          }}
        >
          <motion.div
            className="absolute -top-5 left-1/2 -translate-x-1/2 rounded-full bg-gradient-to-r from-yellow-400 to-amber-500 px-4 py-1 text-lg font-bold text-white"
            animate={{
              y: [0, -5, 0],
              boxShadow: ["0 0 0 rgba(255,215,0,0.7)", "0 0 20px rgba(255,215,0,0.7)", "0 0 0 rgba(255,215,0,0.7)"],
            }}
            transition={{ repeat: Number.POSITIVE_INFINITY, duration: 2 }}
          >
            WINNER
          </motion.div>

          <div className="flex flex-col items-center">
            <motion.div
              className="mb-4 text-8xl"
              animate={{
                scale: [1, 1.2, 1],
                rotate: [0, 5, 0, -5, 0],
              }}
              transition={{ repeat: Number.POSITIVE_INFINITY, duration: 2 }}
            >
              {getAvatarEmoji(winner.avatar)}
            </motion.div>

            <h2 className="mb-2 text-2xl font-bold text-gray-800">{winner.name}</h2>
            <p className="mb-2 text-xl text-gray-700">Score: {winner.score}</p>
            <p className="mb-4 rounded-full bg-pink-100 px-3 py-1 text-sm font-bold text-pink-800">
              {gameResults.winner === "player1" ? gameResults.player1RoundsWon : gameResults.player2RoundsWon} rounds
              won
            </p>

            <motion.div
              className="mt-4"
              initial={{ opacity: 0, scale: 0 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 1 }}
            >
              <div className="relative">
                <span className="text-6xl">🍕</span>
                <span className="absolute -right-2 -top-2 text-3xl">🏆</span>
              </div>
            </motion.div>
          </div>
        </motion.div>

        {/* Loser */}
        <motion.div
          className="rounded-xl border-2 bg-white p-6 shadow-md"
          initial={{ opacity: 0, x: 50, scale: 0.8 }}
          animate={{ opacity: 1, x: 0, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          style={rainbowBorderStyle}
        >
          <div className="flex flex-col items-center">
            <div className="mb-4 text-6xl opacity-70">{getAvatarEmoji(loser.avatar)}</div>

            <h2 className="mb-2 text-xl font-bold text-gray-600">{loser.name}</h2>
            <p className="mb-2 text-lg text-gray-500">Score: {loser.score}</p>
            <p className="mb-4 rounded-full bg-gray-100 px-3 py-1 text-sm font-bold text-gray-600">
              {gameResults.winner === "player1" ? gameResults.player2RoundsWon : gameResults.player1RoundsWon} rounds
              won
            </p>

            <AnimatePresence>
              {showCertificate && (
                <motion.div
                  className="mt-4 rounded-lg border-2 border-dashed bg-gray-50 p-3 text-center"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                  style={rainbowBorderStyle}
                >
                  <p className="text-sm font-medium text-gray-500">Certificate of Participation</p>
                  <p className="text-lg font-bold text-gray-700">World's Okayest SAT-Tackler</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </div>

      <motion.div
        className="mb-8 rounded-lg bg-pink-100 p-4 text-center text-xl font-bold text-pink-800 border-2"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        style={rainbowBorderStyle}
      >
        {getTimeDifferenceText()}
      </motion.div>

      {/* Round Results */}
      <motion.div
        className="mb-8 rounded-lg border-2 bg-white p-6 shadow-lg"
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        style={rainbowBorderStyle}
      >
        <h2 className="mb-4 text-2xl font-bold text-gray-800">Round Details</h2>
        {Object.entries(gameResults.rounds).map(([round, results]) => {
          const player1Result = results.find((r) => r.player === "player1")
          const player2Result = results.find((r) => r.player === "player2")
          const roundWinner =
            player1Result?.isCorrect &&
            (!player2Result?.isCorrect || player1Result.timeRemaining > player2Result.timeRemaining)
              ? players.player1.name
              : player2Result?.isCorrect &&
                  (!player1Result?.isCorrect || player2Result.timeRemaining > player1Result.timeRemaining)
                ? players.player2.name
                : "Tie"

          return (
            <div key={round} className="mb-4 rounded-lg bg-gray-50 p-4">
              <h3 className="mb-2 font-bold text-gray-800">Round {round}</h3>
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <p className="font-medium">{players.player1.name}</p>
                  <p className="text-sm text-gray-600">
                    Answer: {player1Result?.answer || "No answer"}
                    {player1Result?.isCorrect ? " ✅" : " ❌"}
                  </p>
                  {!player1Result?.isCorrect && (
                    <p className="text-sm text-red-600">Correct Answer: {player1Result?.correctAnswer || "N/A"}</p>
                  )}
                  <p className="text-sm text-gray-600">Time: {player1Result?.timeTaken.toFixed(1)}s</p>
                  <p className="text-sm text-gray-700 mt-2">Question: {player1Result?.question || "N/A"}</p>
                </div>
                <div>
                  <p className="font-medium">{players.player2.name}</p>
                  <p className="text-sm text-gray-600">
                    Answer: {player2Result?.answer || "No answer"}
                    {player2Result?.isCorrect ? " ✅" : " ❌"}
                  </p>
                  {!player2Result?.isCorrect && (
                    <p className="text-sm text-red-600">Correct Answer: {player2Result?.correctAnswer || "N/A"}</p>
                  )}
                  <p className="text-sm text-gray-600">Time: {player2Result?.timeTaken.toFixed(1)}s</p>
                  <p className="text-sm text-gray-700 mt-2">Question: {player2Result?.question || "N/A"}</p>
                </div>
              </div>
              <p className="mt-2 text-sm font-medium text-gray-800">Winner: {roundWinner}</p>
            </div>
          )
        })}
      </motion.div>

      {/* Play Again Button */}
      <motion.div
        className="mt-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
      >
        <Button
          onClick={handleRestart}
          className="relative overflow-hidden px-8 py-4 text-xl font-bold text-white shadow-lg transition-all hover:scale-105 hover:shadow-xl"
          style={{
            background: "linear-gradient(to right, #ff0080, #ff8c00, #ffed00, #00ff80, #00bfff, #8a2be2)",
            backgroundSize: "200% auto",
            boxShadow: "0 0 5px rgba(236,72,153,0.5), 0 0 10px rgba(249,115,22,0.5)",
          }}
        >
          Play Again!
          <motion.div
            className="absolute inset-0 -z-10"
            animate={{
              backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"],
            }}
            transition={{
              duration: 3,
              ease: "linear",
              repeat: Number.POSITIVE_INFINITY,
            }}
            style={{
              background: "linear-gradient(to right, #ff0080, #ff8c00, #ffed00, #00ff80, #00bfff, #8a2be2)",
              backgroundSize: "200% auto",
            }}
          />
        </Button>
      </motion.div>
    </div>
  )
}

