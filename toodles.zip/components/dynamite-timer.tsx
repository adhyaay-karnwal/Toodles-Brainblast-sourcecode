"use client"

import { motion } from "framer-motion"
import { useSound } from "@/hooks/use-sound"
import { useEffect, useRef } from "react"

interface DynamiteTimerProps {
  timeLeft: number
  totalTime: number
}

export default function DynamiteTimer({ timeLeft, totalTime }: DynamiteTimerProps) {
  const progress = (timeLeft / totalTime) * 100
  const isLow = timeLeft <= 5
  const isMedium = timeLeft <= 10 && timeLeft > 5
  const { playSound, stopSound } = useSound()
  const timerSoundRef = useRef<NodeJS.Timeout | null>(null)

  useEffect(() => {
    // Play ticking sound with increasing pitch as time runs out
    if (timeLeft > 0) {
      if (timerSoundRef.current) {
        clearInterval(timerSoundRef.current)
      }

      timerSoundRef.current = setInterval(() => {
        const baseRate = 0.8
        const intensityFactor = Math.max(0.2, 1 - timeLeft / totalTime)
        const rate = baseRate + intensityFactor

        if (isLow) {
          playSound("whistle", { rate, volume: 0.3 })
        } else if (isMedium) {
          playSound("pop", { rate: rate * 0.8, volume: 0.2 })
        }
      }, isLow ? 500 : 1000)
    }

    return () => {
      if (timerSoundRef.current) {
        clearInterval(timerSoundRef.current)
      }
    }
  }, [timeLeft, isLow, isMedium])

  // Calculate bounce intensity based on remaining time
  const bounceIntensity = isLow ? 15 : isMedium ? 8 : 3

  // Calculate spark frequency based on remaining time
  const sparkDuration = isLow ? 0.2 : isMedium ? 0.4 : 0.6

  return (
    <div className="relative h-20 w-full">
      {/* Background */}
      <div className="absolute inset-0 rounded-xl bg-gray-100 shadow-inner overflow-hidden">
        {/* Fuse track */}
        <div className="absolute inset-y-0 left-0 right-0 h-4 top-1/2 -translate-y-1/2 bg-gray-200 rounded-full overflow-hidden">
          {/* Burnt fuse part */}
          <motion.div
            className="absolute inset-y-0 right-0 bg-gray-400"
            style={{ width: `${100 - progress}%` }}
            animate={{ width: `${100 - progress}%` }}
            transition={{ duration: 0.5, ease: "easeInOut" }}
          />

          {/* Burning point with sparks */}
          {timeLeft > 0 && (
            <motion.div
              className="absolute top-1/2 -translate-y-1/2 z-10"
              style={{
                left: `${progress}%`,
                width: "12px",
                height: "12px",
              }}
              animate={{
                boxShadow: [
                  "0 0 5px 2px rgba(255,69,0,0.8), 0 0 10px 4px rgba(255,165,0,0.5)",
                  "0 0 8px 3px rgba(255,69,0,0.9), 0 0 15px 6px rgba(255,165,0,0.7)",
                  "0 0 5px 2px rgba(255,69,0,0.8), 0 0 10px 4px rgba(255,165,0,0.5)",
                ],
              }}
              transition={{
                duration: sparkDuration,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            >
              <motion.div
                className="absolute inset-0 rounded-full bg-orange-500"
                animate={{
                  scale: [1, 1.2, 1],
                }}
                transition={{
                  duration: sparkDuration * 0.5,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
              />
            </motion.div>
          )}
        </div>
      </div>
    </div>
  )
}

