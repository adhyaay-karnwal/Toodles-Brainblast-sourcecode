export interface RoundResult {
  player: "player1" | "player2"
  isCorrect: boolean
  timeTaken: number
  timeRemaining: number
  answer: string
  correctAnswer?: string
  question?: string
}

export interface Question {
  question: string
  options: string[]
  correctAnswer: string
  difficulty: "easy" | "medium" | "hard"
  pairId?: string
}

