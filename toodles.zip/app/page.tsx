"use client"

import { useState } from "react"
import StartScreen from "@/components/start-screen"
import LobbyScreen from "@/components/lobby-screen"
import GameScreen from "@/components/game-screen"
import ResultsScreen from "@/components/results-screen"
import { GameProvider } from "@/context/game-context"
import { motion } from "framer-motion"

export default function Home() {
  const [currentScreen, setCurrentScreen] = useState<"start" | "lobby" | "game" | "results">("start")

  return (
    <GameProvider>
      <div className="relative min-h-screen overflow-hidden bg-white">
        {/* Rainbow gradient background */}
        <div className="fixed inset-0 opacity-5">
          <motion.div
            className="absolute inset-0 bg-gradient-to-r from-purple-500 via-blue-500 via-green-500 via-yellow-500 to-red-500"
            animate={{
              backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"],
            }}
            transition={{
              duration: 15,
              ease: "linear",
              repeat: Number.POSITIVE_INFINITY,
            }}
            style={{ backgroundSize: "400% 400%" }}
          />
        </div>

        <div className="relative z-10">
          {currentScreen === "start" && <StartScreen onStart={() => setCurrentScreen("lobby")} />}
          {currentScreen === "lobby" && <LobbyScreen onStart={() => setCurrentScreen("game")} />}
          {currentScreen === "game" && <GameScreen onFinish={() => setCurrentScreen("results")} />}
          {currentScreen === "results" && <ResultsScreen onRestart={() => setCurrentScreen("lobby")} />}
        </div>
      </div>
    </GameProvider>
  )
}

