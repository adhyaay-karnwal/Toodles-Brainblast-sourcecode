"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { useSound } from "@/hooks/use-sound"

interface CountdownScreenProps {
  onComplete: () => void
}

export default function CountdownScreen({ onComplete }: CountdownScreenProps) {
  const [count, setCount] = useState(3)
  const { playSound } = useSound()

  useEffect(() => {
    const interval = setInterval(() => {
      setCount((prev) => {
        if (prev <= 1) {
          clearInterval(interval)
          setTimeout(() => {
            // Play airhorn for longer duration
            playSound("airhorn", { volume: 0.7 })
            onComplete()
          }, 700)
          return 0
        }
        // Play countdown sound with increasing pitch
        playSound("countdown", {
          rate: 1.2 + (3 - prev) * 0.1,
          volume: 0.6,
        })
        return prev - 1
      })
    }, 800) // Faster countdown interval

    return () => clearInterval(interval)
  }, [])

  const colors = ["#ff0080", "#ff8c00", "#ffed00", "#00ff80", "#00bfff", "#8a2be2"]

  return (
    <motion.div
      className="fixed inset-0 z-50 flex items-center justify-center bg-gradient-to-br from-pink-100 to-purple-100"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <AnimatePresence mode="wait">
        {count > 0 ? (
          <motion.div
            key={count}
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{
              scale: [0.5, 1.2, 1],
              opacity: [0, 1, 1],
            }}
            exit={{ scale: 1.5, opacity: 0 }}
            transition={{ duration: 0.6 }}
            className="text-9xl font-bold"
            style={{ color: colors[count % colors.length] }}
          >
            {count}
          </motion.div>
        ) : (
          <motion.div
            key="go"
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{
              scale: [0.5, 1.2, 1],
              opacity: [0, 1, 1],
            }}
            exit={{ scale: 1.5, opacity: 0 }}
            transition={{ duration: 0.6 }}
            className="text-9xl font-bold text-green-500"
          >
            GO!
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}

