export const questions = [
  // PAIR 1: Linear Equations (Basic)
  {
    question: "Solve for x: 2x + 5 = 15",
    options: ["3", "5", "7", "10"],
    correctAnswer: "5",
    difficulty: "easy",
    pairId: 1
  },
  {
    question: "Solve for x: 3(x - 4) = 21",
    options: ["9", "11", "13", "15"],
    correctAnswer: "11",
    difficulty: "medium",
    pairId: 1
  },

  // PAIR 2: Linear Equations (Fractions)
  {
    question: "Solve for x: (1/2)x + 3 = 7",
    options: ["4", "6", "8", "10"],
    correctAnswer: "8",
    difficulty: "medium",
    pairId: 2
  },
  {
    question: "Solve for x: (2/3)x - 5 = 1",
    options: ["6", "9", "12", "15"],
    correctAnswer: "9",
    difficulty: "medium",
    pairId: 2
  },

  // PAIR 3: Quadratic Equations (Factoring)
  {
    question: "Solve x² + 7x + 10 = 0",
    options: ["-2,-5", "-1,-10", "-3,-4", "2,5"],
    correctAnswer: "-2,-5",
    difficulty: "medium",
    pairId: 3
  },
  {
    question: "Solve x² - 5x + 6 = 0",
    options: ["2,3", "1,6", "-2,-3", "-1,-6"],
    correctAnswer: "2,3",
    difficulty: "medium",
    pairId: 3
  },

  // PAIR 4: Quadratic Equations (Formula)
  {
    question: "Solve x² + 4x + 1 = 0 using quadratic formula",
    options: ["-2±√3", "-2±√5", "-4±√3", "-4±√5"],
    correctAnswer: "-2±√3",
    difficulty: "hard",
    pairId: 4
  },
  {
    question: "Solve 2x² - 8x + 3 = 0 using quadratic formula",
    options: ["2±√10/2", "4±√10/2", "2±√5/2", "4±√5/2"],
    correctAnswer: "2±√10/2",
    difficulty: "hard",
    pairId: 4
  },

  // PAIR 5: Geometry (Circles)
  {
    question: "Circle radius 7cm. What's circumference? (π=22/7)",
    options: ["44cm", "66cm", "88cm", "110cm"],
    correctAnswer: "44cm",
    difficulty: "easy",
    pairId: 5
  },
  {
    question: "Circle diameter 14m. What's area? (π=22/7)",
    options: ["154m²", "308m²", "462m²", "616m²"],
    correctAnswer: "154m²",
    difficulty: "medium",
    pairId: 5
  },

  // PAIR 6: Geometry (Triangles)
  {
    question: "Right triangle legs 3cm and 4cm. Hypotenuse?",
    options: ["5cm", "6cm", "7cm", "8cm"],
    correctAnswer: "5cm",
    difficulty: "easy",
    pairId: 6
  },
  {
    question: "Triangle area with base 12m and height 5m?",
    options: ["30m²", "45m²", "60m²", "75m²"],
    correctAnswer: "30m²",
    difficulty: "easy",
    pairId: 6
  },

  // PAIR 7: Probability (Basic)
  {
    question: "Probability of rolling a 3 on a die?",
    options: ["1/6", "1/3", "1/2", "2/3"],
    correctAnswer: "1/6",
    difficulty: "easy",
    pairId: 7
  },
  {
    question: "Probability of drawing a heart from standard deck?",
    options: ["1/4", "1/3", "1/2", "2/5"],
    correctAnswer: "1/4",
    difficulty: "medium",
    pairId: 7
  },

  // PAIR 8: Probability (Compound)
  {
    question: "Flip two coins. P(both heads)?",
    options: ["1/4", "1/3", "1/2", "3/4"],
    correctAnswer: "1/4",
    difficulty: "medium",
    pairId: 8
  },
  {
    question: "Bag has 3 red, 2 blue. P(drawing red)?",
    options: ["3/5", "2/5", "1/2", "3/4"],
    correctAnswer: "3/5",
    difficulty: "medium",
    pairId: 8
  },

  // PAIR 9: Algebra (Word Problems)
  {
    question: "If 5 apples cost $7.50, what's unit price?",
    options: ["$1.25", "$1.50", "$1.75", "$2.00"],
    correctAnswer: "$1.50",
    difficulty: "easy",
    pairId: 9
  },
  {
    question: "Train travels 300km in 2.5 hours. Average speed?",
    options: ["100 km/h", "120 km/h", "125 km/h", "150 km/h"],
    correctAnswer: "120 km/h",
    difficulty: "medium",
    pairId: 9
  },

  // PAIR 10: Exponents
  {
    question: "Simplify 2³ × 2⁵",
    options: ["2⁸", "2¹⁵", "4⁸", "8⁸"],
    correctAnswer: "2⁸",
    difficulty: "medium",
    pairId: 10
  },
  {
    question: "Simplify (5²)⁴",
    options: ["5⁶", "5⁸", "25⁶", "25⁸"],
    correctAnswer: "5⁸",
    difficulty: "medium",
    pairId: 10
  },

  // PAIR 11: Logarithms
  {
    question: "Solve log₂ 16 = x",
    options: ["2", "4", "6", "8"],
    correctAnswer: "4",
    difficulty: "medium",
    pairId: 11
  },
  {
    question: "Solve ln(e⁵) = x",
    options: ["1", "5", "e", "e⁵"],
    correctAnswer: "5",
    difficulty: "medium",
    pairId: 11
  },

  // PAIR 12: Trigonometry (Basic)
  {
    question: "sin(30°) = ?",
    options: ["0.5", "√3/2", "1", "0.707"],
    correctAnswer: "0.5",
    difficulty: "easy",
    pairId: 12
  },
  {
    question: "cos(60°) = ?",
    options: ["0.5", "√3/2", "1", "0.707"],
    correctAnswer: "0.5",
    difficulty: "easy",
    pairId: 12
  },

  // PAIR 13: Trigonometry (Identities)
  {
    question: "Simplify sin²θ + cos²θ",
    options: ["0", "1", "2", "tanθ"],
    correctAnswer: "1",
    difficulty: "medium",
    pairId: 13
  },
  {
    question: "Simplify tanθ × cotθ",
    options: ["0", "1", "sinθ", "cosθ"],
    correctAnswer: "1",
    difficulty: "medium",
    pairId: 13
  },

  // PAIR 14: Functions
  {
    question: "f(x) = 2x + 3. Find f(4)",
    options: ["9", "10", "11", "12"],
    correctAnswer: "11",
    difficulty: "easy",
    pairId: 14
  },
  {
    question: "g(x) = x² - 4. Find g(-2)",
    options: ["-8", "0", "4", "8"],
    correctAnswer: "0",
    difficulty: "easy",
    pairId: 14
  },

  // PAIR 15: Inequalities
  {
    question: "Solve 2x + 5 > 15",
    options: ["x > 5", "x > 10", "x < 5", "x < 10"],
    correctAnswer: "x > 5",
    difficulty: "medium",
    pairId: 15
  },
  {
    question: "Solve -3x ≤ 12",
    options: ["x ≥ -4", "x ≤ -4", "x ≥ 4", "x ≤ 4"],
    correctAnswer: "x ≥ -4",
    difficulty: "medium",
    pairId: 15
  },

  // PAIR 16: Systems of Equations
  {
    question: "Solve: x + y = 10, x - y = 2",
    options: ["(6,4)", "(5,5)", "(8,2)", "(7,3)"],
    correctAnswer: "(6,4)",
    difficulty: "medium",
    pairId: 16
  },
  {
    question: "Solve: 2x + y = 11, x - y = 4",
    options: ["(5,1)", "(6,2)", "(7,3)", "(8,4)"],
    correctAnswer: "(5,1)",
    difficulty: "medium",
    pairId: 16
  },

  // PAIR 17: Polynomials
  {
    question: "Degree of 3x² + 5x³ - 2x + 7?",
    options: ["1", "2", "3", "4"],
    correctAnswer: "3",
    difficulty: "easy",
    pairId: 17
  },
  {
    question: "Add: (3x² + 2x) + (5x² - 4x)",
    options: ["8x² - 2x", "8x² + 6x", "2x² - 2x", "15x² - 8x"],
    correctAnswer: "8x² - 2x",
    difficulty: "medium",
    pairId: 17
  },

  // PAIR 18: Coordinate Geometry
  {
    question: "Distance between (2,3) and (5,7)?",
    options: ["3", "4", "5", "6"],
    correctAnswer: "5",
    difficulty: "medium",
    pairId: 18
  },
  {
    question: "Midpoint between (4,6) and (8,12)?",
    options: ["(6,9)", "(5,8)", "(7,10)", "(8,12)"],
    correctAnswer: "(6,9)",
    difficulty: "medium",
    pairId: 18
  },

  // PAIR 19: Volume
  {
    question: "Cube with side 3cm. Volume?",
    options: ["9cm³", "18cm³", "27cm³", "36cm³"],
    correctAnswer: "27cm³",
    difficulty: "easy",
    pairId: 19
  },
  {
    question: "Cylinder radius 2m, height 5m. Volume? (π=3.14)",
    options: ["15.7m³", "31.4m³", "62.8m³", "125.6m³"],
    correctAnswer: "62.8m³",
    difficulty: "medium",
    pairId: 19
  },

  // PAIR 20: Surface Area
  {
    question: "Cube with edge 4cm. Surface area?",
    options: ["64cm²", "96cm²", "128cm²", "256cm²"],
    correctAnswer: "96cm²",
    difficulty: "medium",
    pairId: 20
  },
  {
    question: "Sphere radius 3m. Surface area? (4πr²)",
    options: ["12πm²", "24πm²", "36πm²", "48πm²"],
    correctAnswer: "36πm²",
    difficulty: "medium",
    pairId: 20
  },

  // PAIR 21: Percentages
  {
    question: "20% of 150 = ?",
    options: ["15", "20", "30", "45"],
    correctAnswer: "30",
    difficulty: "easy",
    pairId: 21
  },
  {
    question: "If 40 is 20% of a number, what's the number?",
    options: ["100", "150", "200", "250"],
    correctAnswer: "200",
    difficulty: "medium",
    pairId: 21
  },

  // PAIR 22: Ratios
  {
    question: "Simplify 16:24",
    options: ["2:3", "3:4", "4:5", "8:12"],
    correctAnswer: "2:3",
    difficulty: "easy",
    pairId: 22
  },
  {
    question: "If 2:5 = 8:x, find x",
    options: ["10", "15", "20", "25"],
    correctAnswer: "20",
    difficulty: "medium",
    pairId: 22
  },

  // PAIR 23: Interest Problems
  {
    question: "Simple interest on $1000 at 5% for 2 years",
    options: ["$50", "$100", "$150", "$200"],
    correctAnswer: "$100",
    difficulty: "medium",
    pairId: 23
  },
  {
    question: "Compound interest $2000 at 10% annually for 2 years",
    options: ["$200", "$420", "$440", "$480"],
    correctAnswer: "$420",
    difficulty: "hard",
    pairId: 23
  },

  // PAIR 24: Sequences
  {
    question: "Next in sequence: 2, 4, 8, 16...",
    options: ["18", "20", "24", "32"],
    correctAnswer: "32",
    difficulty: "easy",
    pairId: 24
  },
  {
    question: "Arithmetic sequence: 5, 9, 13, ___",
    options: ["15", "17", "19", "21"],
    correctAnswer: "17",
    difficulty: "medium",
    pairId: 24
  },

  // PAIR 25: Calculus (Derivatives)
  {
    question: "Derivative of 4x³ - 3x² + 2x - 5",
    options: ["12x² - 6x + 2", "12x² - 3x + 2", "4x² - 3x + 2", "12x² - 6x"],
    correctAnswer: "12x² - 6x + 2",
    difficulty: "hard",
    pairId: 25
  },
  {
    question: "Derivative of sin(x)",
    options: ["cos(x)", "-cos(x)", "tan(x)", "-sin(x)"],
    correctAnswer: "cos(x)",
    difficulty: "hard",
    pairId: 25
  },

  // PAIR 26: Calculus (Integrals)
  {
    question: "∫(3x² + 2x) dx",
    options: ["x³ + x² + C", "3x³ + x² + C", "x³ + 2x² + C", "6x + 2 + C"],
    correctAnswer: "x³ + x² + C",
    difficulty: "hard",
    pairId: 26
  },
  {
    question: "∫cos(x) dx",
    options: ["sin(x) + C", "-sin(x) + C", "cos(x) + C", "-cos(x) + C"],
    correctAnswer: "sin(x) + C",
    difficulty: "hard",
    pairId: 26
  },

  // PAIR 27: Matrices
  {
    question: "What is the determinant of [[2,3],[1,4]]?",
    options: ["5", "6", "7", "8"],
    correctAnswer: "5",
    difficulty: "hard",
    pairId: 27
  },
  {
    question: "Matrix addition: [[1,2],[3,4]] + [[5,6],[7,8]]",
    options: ["[[6,8],[10,12]]", "[[5,8],[10,12]]", "[[6,7],[10,11]]", "[[7,8],[9,10]]"],
    correctAnswer: "[[6,8],[10,12]]",
    difficulty: "medium",
    pairId: 27
  },

  // PAIR 28: Vectors
  {
    question: "Magnitude of vector (3,4)",
    options: ["5", "7", "12", "25"],
    correctAnswer: "5",
    difficulty: "medium",
    pairId: 28
  },
  {
    question: "Dot product of (2,3) and (4,5)",
    options: ["12", "15", "23", "27"],
    correctAnswer: "23",
    difficulty: "hard",
    pairId: 28
  },

  // PAIR 29: Complex Numbers
  {
    question: "Simplify (3 + 2i) + (1 - 4i)",
    options: ["4 - 2i", "2 + 6i", "3 - 2i", "4 + 6i"],
    correctAnswer: "4 - 2i",
    difficulty: "medium",
    pairId: 29
  }
];

// Function to shuffle question pairs while keeping pairs together
export const getRandomizedQuestionPairs = () => {
  const pairs = new Map();
  
  // Group questions by pairId
  questions.forEach(q => {
    if (!pairs.has(q.pairId)) {
      pairs.set(q.pairId, []);
    }
    pairs.get(q.pairId).push(q);
  });

  // Convert pairs to array and shuffle
  const pairArray = Array.from(pairs.values());
  for (let i = pairArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [pairArray[i], pairArray[j]] = [pairArray[j], pairArray[i]];
  }

  // Flatten the array while keeping pairs together
  return pairArray.flat();
};

