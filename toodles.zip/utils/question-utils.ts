import { questions } from "@/data/questions"

// Function to create alternate versions of questions with different numbers
function createAlternateQuestion(question: any) {
  // Clone the question to avoid modifying the original
  const alternate = { ...question }

  // Create a new question based on the type/pattern of the original
  if (question.question.includes("=")) {
    // For equations, modify the numbers
    const newQuestion = modifyEquation(question.question)
    alternate.question = newQuestion.question

    // Update options and correct answer
    const optionMultiplier = newQuestion.multiplier || 1
    alternate.options = question.options.map((opt: string) => {
      // If the option is a number, multiply it
      if (!isNaN(Number.parseFloat(opt))) {
        return (Number.parseFloat(opt) * optionMultiplier).toString()
      }
      // If it contains numbers, try to modify those
      else if (/\d/.test(opt)) {
        return modifyNumbersInText(opt, optionMultiplier)
      }
      return opt
    })

    // Update correct answer
    if (!isNaN(Number.parseFloat(question.correctAnswer))) {
      alternate.correctAnswer = (Number.parseFloat(question.correctAnswer) * optionMultiplier).toString()
    } else if (/\d/.test(question.correctAnswer)) {
      alternate.correctAnswer = modifyNumbersInText(question.correctAnswer, optionMultiplier)
    } else {
      alternate.correctAnswer = question.correctAnswer
    }
  } else if (
    question.question.includes("triangle") ||
    question.question.includes("circle") ||
    question.question.includes("square")
  ) {
    // For geometry questions, modify dimensions
    alternate.question = modifyGeometryQuestion(question.question)

    // Update options with scaled values
    const scaleFactor = 1.5 // Scale by 50%
    alternate.options = question.options.map((opt: string) => {
      if (!isNaN(Number.parseFloat(opt))) {
        return Math.round(Number.parseFloat(opt) * scaleFactor).toString()
      }
      return opt
    })

    // Update correct answer if it's a number
    if (!isNaN(Number.parseFloat(question.correctAnswer))) {
      alternate.correctAnswer = Math.round(Number.parseFloat(question.correctAnswer) * scaleFactor).toString()
    } else {
      alternate.correctAnswer = question.correctAnswer
    }
  } else {
    // For other questions, modify numbers if present
    alternate.question = modifyNumbersInText(question.question)

    // Try to adjust options and correct answer accordingly
    const multiplier = 1.2 // Simple multiplier for numeric values
    alternate.options = question.options.map((opt: string) => {
      if (!isNaN(Number.parseFloat(opt))) {
        return Math.round(Number.parseFloat(opt) * multiplier).toString()
      }
      return opt
    })

    if (!isNaN(Number.parseFloat(question.correctAnswer))) {
      alternate.correctAnswer = Math.round(Number.parseFloat(question.correctAnswer) * multiplier).toString()
    } else {
      alternate.correctAnswer = question.correctAnswer
    }
  }

  return alternate
}

// Helper function to modify equations
function modifyEquation(equation: string) {
  // Simple approach: multiply all numbers by a random factor
  const multiplier = Math.random() > 0.5 ? 2 : 0.5

  // Replace numbers in the equation
  const modifiedEquation = equation.replace(/\d+/g, (match) => {
    const num = Number.parseInt(match)
    return Math.round(num * multiplier).toString()
  })

  return { question: modifiedEquation, multiplier }
}

// Helper function to modify numbers in text
function modifyNumbersInText(text: string, multiplier = 1.5) {
  return text.replace(/\d+/g, (match) => {
    const num = Number.parseInt(match)
    return Math.round(num * multiplier).toString()
  })
}

// Helper function to modify geometry questions
function modifyGeometryQuestion(question: string) {
  // Replace dimensions with different values
  return question.replace(/\d+/g, (match) => {
    const num = Number.parseInt(match)
    // Use a different multiplier to create variety
    const multiplier = Math.random() > 0.5 ? 1.5 : 0.75
    return Math.round(num * multiplier).toString()
  })
}

// Track used question pairs
let usedPairIds = new Set<string>();
let allPairIds: string[] = [];

export function getRandomQuestionPairs(count: number) {
  // Group questions by pairId
  const questionPairs = questions.reduce((pairs: any, question: any) => {
    if (question.pairId) {
      if (!pairs[question.pairId]) {
        pairs[question.pairId] = [];
      }
      pairs[question.pairId].push(question);
    }
    return pairs;
  }, {});

  // Get all valid pairs (pairs with exactly 2 questions)
  const validPairIds = Object.entries(questionPairs)
    .filter(([_, pair]: [string, any]) => pair.length === 2)
    .map(([pairId]) => pairId);

  // If no valid pairs, return empty array
  if (validPairIds.length === 0) return [];

  // Initialize or reset allPairIds if needed
  if (allPairIds.length === 0 || usedPairIds.size >= validPairIds.length) {
    allPairIds = [...validPairIds];
    usedPairIds.clear();
  }

  // Get available pairs (not used yet)
  const availablePairIds = validPairIds.filter(pairId => !usedPairIds.has(pairId));

  // Shuffle available pairs
  const shuffledPairIds = availablePairIds.sort(() => Math.random() - 0.5);

  // Take required number of pairs
  const selectedPairIds = shuffledPairIds.slice(0, count);

  // Mark selected pairs as used
  selectedPairIds.forEach(pairId => usedPairIds.add(pairId));

  // Convert selected pair IDs to actual question pairs
  const resultPairs = selectedPairIds.map(pairId => {
    const pair = questionPairs[pairId];
    return [
      { ...pair[0], difficulty: pair[0].difficulty || 'medium' },
      { ...pair[1], difficulty: pair[1].difficulty || 'medium' }
    ];
  });

  return resultPairs;
}

interface ShuffledOption {
  text: string
  isCorrect: boolean
}

export function shuffleAnswers(question: any) {
  if (!question) return []

  // Create an array of options with their correctness
  const options = question.options.map((option: string) => ({
    text: option,
    isCorrect: option === question.correctAnswer,
  }))

  // Shuffle the options
  return options.sort(() => Math.random() - 0.5)
}

