"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { useGame } from "@/context/game-context"
import { useSound } from "@/hooks/use-sound"

interface LobbyScreenProps {
  onStart: () => void
}

const avatars = [
  {
    id: "taco",
    name: "Dancing Taco",
    emoji: "🌮",
    description: "Spicy moves, cheesy jokes!",
  },
  {
    id: "pineapple",
    name: "Disco Pineapple",
    emoji: "🍍",
    description: "Tropical vibes, funky jives!",
  },
  {
    id: "wizard",
    name: "Math Wizard",
    emoji: "🧙",
    description: "Calculates your doom!",
  },
  {
    id: "pencil",
    name: "Giant Pencil",
    emoji: "✏️",
    description: "Points well taken!",
  },
]

export default function LobbyScreen({ onStart }: LobbyScreenProps) {
  const { setPlayers } = useGame()
  const { playSound } = useSound()
  const [player1, setPlayer1] = useState({
    name: "",
    avatar: "",
  })
  const [player2, setPlayer2] = useState({
    name: "",
    avatar: "",
  })

  const handleStart = () => {
    if (player1.name && player1.avatar && player2.name && player2.avatar) {
      setPlayers({
        player1: {
          name: player1.name,
          avatar: player1.avatar,
          score: 0,
          roundsWon: 0,
        },
        player2: {
          name: player2.name,
          avatar: player2.avatar,
          score: 0,
          roundsWon: 0,
        },
      })
      playSound("airhorn")
      onStart()
    }
  }

  const isFormValid = player1.name && player1.avatar && player2.name && player2.avatar

  return (
    <div className="container mx-auto flex min-h-screen flex-col items-center justify-center p-4">
      <motion.h1
        className="mb-8 text-center text-4xl font-extrabold tracking-tight text-gray-800 md:text-5xl"
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
        style={{
          textShadow: "0 0 2px rgba(138,43,226,0.5), 0 0 4px rgba(75,0,130,0.5)",
        }}
      >
        Choose Your Math Warriors!
      </motion.h1>

      <div className="grid w-full max-w-4xl gap-8 md:grid-cols-2">
        <PlayerSetup playerNumber={1} player={player1} setPlayer={setPlayer1} otherPlayerAvatar={player2.avatar} />
        <PlayerSetup playerNumber={2} player={player2} setPlayer={setPlayer2} otherPlayerAvatar={player1.avatar} />
      </div>

      <motion.div
        className="mt-12"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
      >
        <Button
          onClick={handleStart}
          disabled={!isFormValid}
          className="relative overflow-hidden px-8 py-6 text-xl font-bold text-white shadow-lg transition-all hover:scale-105 hover:shadow-xl disabled:opacity-50"
          style={{
            background: "linear-gradient(to right, #ff0080, #ff8c00, #ffed00, #00ff80, #00bfff, #8a2be2)",
            backgroundSize: "200% auto",
            boxShadow: isFormValid ? "0 0 5px rgba(138,43,226,0.5), 0 0 10px rgba(75,0,130,0.5)" : "none",
          }}
        >
          BATTLE TIME!
          <motion.div
            className="absolute inset-0 -z-10"
            animate={{
              backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"],
            }}
            transition={{
              duration: 3,
              ease: "linear",
              repeat: Number.POSITIVE_INFINITY,
            }}
            style={{
              background: "linear-gradient(to right, #ff0080, #ff8c00, #ffed00, #00ff80, #00bfff, #8a2be2)",
              backgroundSize: "200% auto",
            }}
          />
        </Button>
      </motion.div>
    </div>
  )
}

interface PlayerSetupProps {
  playerNumber: number
  player: { name: string; avatar: string }
  setPlayer: React.Dispatch<React.SetStateAction<{ name: string; avatar: string }>>
  otherPlayerAvatar: string
}

function PlayerSetup({ playerNumber, player, setPlayer, otherPlayerAvatar }: PlayerSetupProps) {
  const { playSound } = useSound()

  return (
    <motion.div
      className="rounded-xl border-2 border-dashed border-purple-300 bg-white p-6 shadow-lg"
      initial={{ opacity: 0, x: playerNumber === 1 ? -50 : 50 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5, delay: 0.2 * playerNumber }}
      style={{
        boxShadow: "0 0 5px rgba(255,0,128,0.2), 0 0 10px rgba(138,43,226,0.2)",
        borderImage: "linear-gradient(45deg, #ff0080, #ff8c00, #ffed00, #00ff80, #00bfff, #8a2be2) 1",
        borderImageSlice: 1,
      }}
    >
      <h2 className="mb-4 text-center text-2xl font-bold text-gray-800">Player {playerNumber}</h2>

      <div className="mb-6">
        <Label htmlFor={`player${playerNumber}-name`} className="mb-2 block text-gray-700">
          Your Genius Name:
        </Label>
        <Input
          id={`player${playerNumber}-name`}
          placeholder={playerNumber === 1 ? "Sir-Calculates-A-Lot" : "Algebruh"}
          value={player.name}
          onChange={(e) => {
            setPlayer({ ...player, name: e.target.value })
            if (e.target.value.length === 1) playSound("pop")
          }}
          className="border-2 border-purple-200 bg-white"
        />
      </div>

      <div>
        <Label className="mb-2 block text-gray-700">Choose Your Avatar:</Label>
        <RadioGroup
          value={player.avatar}
          onValueChange={(value) => {
            setPlayer({ ...player, avatar: value })
            playSound("pop")
          }}
        >
          <div className="grid grid-cols-2 gap-3">
            {avatars.map((avatar) => (
              <div
                key={avatar.id}
                className={`relative rounded-lg border-2 ${
                  player.avatar === avatar.id ? "border-purple-500 bg-purple-50" : "border-gray-200"
                } ${
                  otherPlayerAvatar === avatar.id
                    ? "cursor-not-allowed opacity-50"
                    : "cursor-pointer hover:border-purple-300"
                }`}
              >
                <RadioGroupItem
                  value={avatar.id}
                  id={`${playerNumber}-${avatar.id}`}
                  className="sr-only"
                  disabled={otherPlayerAvatar === avatar.id}
                />
                <Label
                  htmlFor={`${playerNumber}-${avatar.id}`}
                  className={`flex flex-col items-center p-3 ${
                    otherPlayerAvatar === avatar.id ? "cursor-not-allowed" : "cursor-pointer"
                  }`}
                >
                  <span className="text-4xl">{avatar.emoji}</span>
                  <span className="mt-1 text-sm font-medium text-gray-800">{avatar.name}</span>
                  <span className="mt-1 text-xs text-gray-500">{avatar.description}</span>
                </Label>
              </div>
            ))}
          </div>
        </RadioGroup>
      </div>
    </motion.div>
  )
}

