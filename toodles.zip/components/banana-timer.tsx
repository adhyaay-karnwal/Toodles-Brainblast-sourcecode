"use client"

import { motion } from "framer-motion"
import { useEffect, useRef, useState } from "react"
import { useSound } from "@/hooks/use-sound"

interface BananaTimerProps {
  timeLeft: number
  totalTime: number
  difficulty: 'easy' | 'medium' | 'hard'
}

export default function BananaTimer({ timeLeft, totalTime, difficulty }: BananaTimerProps) {
  const { playSound, stopSound } = useSound()
  const prevTimeRef = useRef(timeLeft)
  const [milliseconds, setMilliseconds] = useState(0)

  useEffect(() => {
    let interval: NodeJS.Timeout

    if (timeLeft > 0) {
      interval = setInterval(() => {
        setMilliseconds((prev) => {
          if (prev <= 0) {
            return 999
          }
          return prev - 16
        })
      }, 16)
    } else {
      setMilliseconds(0)
    }

    return () => clearInterval(interval)
  }, [timeLeft])

  useEffect(() => {
    if (timeLeft !== prevTimeRef.current && timeLeft > 0) {
      setMilliseconds(999) // Reset milliseconds when second changes
      const baseRate = 1.0
      const timePercentage = timeLeft / totalTime
      const pitchIncrease = (1 - timePercentage) * 1.5

      playSound("timerCountDownBeep", { 
        volume: timeLeft <= 5 ? 0.6 : timeLeft <= 10 ? 0.4 : 0.3,
        rate: baseRate + pitchIncrease
      })
    }

    if (timeLeft === 0) {
      stopSound("timerCountDownBeep")
    }

    prevTimeRef.current = timeLeft
  }, [timeLeft, totalTime])

  const progress = (timeLeft / totalTime) * 100
  const isLow = timeLeft <= 5
  const isMedium = timeLeft <= 10 && timeLeft > 5

  const timerColor = isLow ? "#ef4444" : isMedium ? "#f97316" : "#f59e0b"

  return (
    <div className="relative h-16 w-full overflow-hidden rounded-full bg-yellow-100">
      {/* Difficulty Indicator */}
      <div className="absolute -top-6 left-1/2 -translate-x-1/2 transform">
        <motion.div
          className={`font-bold uppercase ${difficulty === 'easy' ? 'text-green-600' : difficulty === 'medium' ? 'text-orange-600' : 'text-red-600'}`}
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.3 }}
        >
          {difficulty}
        </motion.div>
      </div>

      {/* Progress Bar */}
      <motion.div
        className="absolute inset-y-0 left-0"
        style={{
          width: `${progress}%`,
          boxShadow: isLow ? "0 0 10px rgba(239,68,68,0.7), 0 0 20px rgba(239,68,68,0.4)" : isMedium ? "0 0 8px rgba(249,115,22,0.6)" : "",
        }}
        animate={{
          width: `${progress}%`,
          boxShadow: isLow ? ["0 0 10px rgba(239,68,68,0.7)", "0 0 20px rgba(239,68,68,0.9)", "0 0 10px rgba(239,68,68,0.7)"] : undefined,
        }}
        transition={{
          duration: 0.5,
          ease: "easeInOut",
        }}
      >
        <svg viewBox="0 0 200 40" preserveAspectRatio="none" className="h-full w-full">
          <motion.path
            d="M0,20 C20,40 50,40 70,20 C90,0 110,0 130,20 C150,40 180,40 200,20 L200,40 L0,40 Z"
            fill={timerColor}
            animate={isLow ? { fill: ["#ef4444", "#f97316", "#ef4444"] } : undefined}
            transition={isLow ? { duration: 0.5, repeat: Number.POSITIVE_INFINITY } : undefined}
            className="drop-shadow-md"
          />
        </svg>
      </motion.div>

      {/* Timer Text */}
      <div className="absolute inset-0 flex items-center justify-center">
        <motion.div
          className="font-mono text-3xl font-bold flex items-baseline gap-1"
          style={{ color: isLow ? "#ef4444" : isMedium ? "#f97316" : "#92400e" }}
          animate={{
            scale: isLow ? [1, 1.3, 1] : isMedium ? [1, 1.1, 1] : 1,
            color: isLow ? ["#ef4444", "#b91c1c", "#ef4444"] : isMedium ? ["#f97316", "#ea580c", "#f97316"] : "#92400e",
          }}
          transition={{
            duration: 0.5,
            repeat: Number.POSITIVE_INFINITY,
          }}
        >
          <span>{timeLeft}</span>
          <span className="text-xl">.{String(milliseconds).padStart(3, "0")}</span>
        </motion.div>
      </div>
    </div>
  )
}

