"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"

interface VialTimerProps {
  timeLeft: number
  totalTime: number
}

export default function VialTimer({ timeLeft, totalTime }: VialTimerProps) {
  const [milliseconds, setMilliseconds] = useState(0)
  const progress = (timeLeft / totalTime) * 100
  const isLow = timeLeft <= 5
  const isMedium = timeLeft <= 10 && timeLeft > 5

  // Update milliseconds every 10ms
  useEffect(() => {
    if (timeLeft <= 0) {
      setMilliseconds(0)
      return
    }

    const interval = setInterval(() => {
      setMilliseconds((prev) => (prev + 10) % 1000)
    }, 10)

    return () => clearInterval(interval)
  }, [timeLeft])

  return (
    <div className="relative h-24 w-full flex items-center justify-center mb-4">
      {/* Glass vial container - now horizontal */}
      <div className="relative h-16 w-full max-w-3xl mx-auto rounded-full overflow-hidden border-2 border-gray-300 shadow-md">
        {/* Glass effect */}
        <div
          className="absolute inset-0 rounded-full"
          style={{
            background:
              "linear-gradient(135deg, rgba(255,255,255,0.4) 0%, rgba(255,255,255,0.1) 50%, rgba(255,255,255,0) 51%, rgba(255,255,255,0.1) 100%)",
            boxShadow: "inset 0 0 20px rgba(255,255,255,0.4), 0 0 15px rgba(0,0,0,0.1)",
          }}
        />

        {/* Rainbow liquid fill - now fills from left to right */}
        <motion.div
          className="absolute top-0 bottom-0 left-0 rounded-full"
          style={{
            background: "linear-gradient(to right, #ff0080, #ff8c00, #ffed00, #00ff80, #00bfff, #8a2be2)",
            backgroundSize: "200% auto",
            width: `${progress}%`,
            boxShadow: isLow ? "0 0 15px rgba(255,0,0,0.7)" : "none",
          }}
          animate={{
            backgroundPosition: ["0% center", "200% center"],
            boxShadow: isLow
              ? ["0 0 15px rgba(255,0,0,0.7)", "0 0 25px rgba(255,0,0,0.9)", "0 0 15px rgba(255,0,0,0.7)"]
              : undefined,
          }}
          transition={{
            backgroundPosition: { duration: 3, repeat: Number.POSITIVE_INFINITY, ease: "linear" },
            boxShadow: isLow ? { duration: 0.5, repeat: Number.POSITIVE_INFINITY } : undefined,
          }}
        >
          {/* Bubbles effect */}
          {Array.from({ length: 8 }).map((_, i) => (
            <motion.div
              key={i}
              className="absolute rounded-full bg-white opacity-70"
              style={{
                width: Math.random() * 10 + 5,
                height: Math.random() * 10 + 5,
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
              animate={{
                x: [0, 50 + Math.random() * 50],
                opacity: [0.7, 0],
                scale: [1, 0.5],
              }}
              transition={{
                duration: 1 + Math.random() * 2,
                repeat: Number.POSITIVE_INFINITY,
                delay: Math.random() * 2,
                ease: "easeOut",
              }}
            />
          ))}
        </motion.div>

        {/* Reflection overlay */}
        <div
          className="absolute inset-0 rounded-full"
          style={{
            background:
              "linear-gradient(135deg, rgba(255,255,255,0.2) 0%, rgba(255,255,255,0.05) 40%, rgba(255,255,255,0) 41%, rgba(255,255,255,0) 100%)",
            pointerEvents: "none",
          }}
        />
      </div>

      {/* Timer text */}
      <div className="absolute inset-0 flex items-center justify-center">
        <motion.div
          className="font-mono font-bold flex items-baseline"
          animate={{
            scale: isLow ? [1, 1.1, 1] : 1,
            color: isLow ? ["#ef4444", "#b91c1c", "#ef4444"] : isMedium ? ["#f97316", "#ea580c", "#f97316"] : "#1e293b",
            textShadow: isLow
              ? ["0 0 5px rgba(239,68,68,0.5)", "0 0 10px rgba(239,68,68,0.8)", "0 0 5px rgba(239,68,68,0.5)"]
              : undefined,
          }}
          transition={{
            duration: isLow ? 0.3 : 0.6,
            repeat: isLow || isMedium ? Number.POSITIVE_INFINITY : 0,
          }}
        >
          <span className="text-5xl mr-1">{timeLeft}</span>
          <span className="text-2xl">.{String(milliseconds).padStart(3, "0").substring(0, 2)}</span>
        </motion.div>
      </div>

      {/* Time's up explosion */}
      {timeLeft === 0 && (
        <motion.div
          className="absolute inset-0 flex items-center justify-center"
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3 }}
        >
          <motion.div
            className="w-full h-full rounded-xl"
            style={{
              background:
                "radial-gradient(circle, rgba(255,0,128,0.8) 0%, rgba(255,140,0,0.7) 25%, rgba(255,237,0,0.6) 50%, rgba(0,255,128,0.5) 75%, rgba(0,191,255,0.4) 100%)",
            }}
            animate={{
              scale: [1, 1.5, 0.8],
              opacity: [1, 0.8, 0],
            }}
            transition={{ duration: 1.5 }}
          />
          <motion.div
            className="absolute inset-0 flex items-center justify-center"
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: [0, 1, 0], scale: [0.5, 1.2, 1.5] }}
            transition={{ duration: 1.5, times: [0, 0.3, 1] }}
          >
            <div className="text-6xl font-bold text-white text-center drop-shadow-lg">TIME'S UP!</div>
          </motion.div>
        </motion.div>
      )}
    </div>
  )
}

