// Sound effect URLs from Freesound.org
export const SOUND_URLS = {
  // Playful pop sound for interactions and countdown
  pop: "https://cdn.freesound.org/previews/575/575506_11871271-lq.mp3",

  // Cheerful success sounds
  chaching: "https://cdn.freesound.org/previews/554/554841_12425847-lq.mp3",
  cheer: "https://cdn.freesound.org/previews/651/651640_5315864-lq.mp3",

  // Fun failure sounds
  fart: "https://cdn.freesound.org/previews/253/253857_4062622-lq.mp3",
  trombone: "https://cdn.freesound.org/previews/73/73581_634166-lq.mp3",

  // Timer and alert sounds
  whistle: "https://cdn.freesound.org/previews/218/218318_1480854-lq.mp3",
  slip: "https://cdn.freesound.org/previews/110/110390_1930766-lq.mp3",

  // Celebration sounds
  airhorn: "https://cdn.freesound.org/previews/414/414208_6938106-lq.mp3",
  backgroundMusic: "https://cdn.freesound.org/previews/628/628445_13898385-lq.mp3",
  boing: "https://cdn.freesound.org/previews/384/384843_1676145-lq.mp3",

  timerCountDownBeep: "https://cdn.freesound.org/previews/450/450614_9159316-lq.mp3",
  countdown: "https://cdn.freesound.org/previews/653/653956_3431081-lq.mp3",
} as const

export type SoundType = keyof typeof SOUND_URLS

