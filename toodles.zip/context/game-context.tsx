"use client"

import { createContext, useContext, useState, type ReactNode } from "react"
import type { RoundResult } from "@/types/game-types"

type Avatar = "taco" | "pineapple" | "wizard" | "pencil"

interface Player {
  name: string
  avatar: string
  score: number
  roundsWon: number
}

interface Players {
  player1: Player
  player2: Player
}

interface GameResults {
  player1Score: number
  player2Score: number
  player1RoundsWon: number
  player2RoundsWon: number
  winner: "player1" | "player2" | null
  rounds: Record<number, RoundResult[]>
}

interface GameContextType {
  players: Players
  setPlayers: (players: Players) => void
  currentPlayer: "player1" | "player2"
  setCurrentPlayer: (player: "player1" | "player2") => void
  updateScore: (player: "player1" | "player2", points: number) => void
  updateRoundsWon: (player: "player1" | "player2") => void
  gameResults: GameResults
  setGameResults: (results: GameResults) => void
  roundResults: Record<number, RoundResult[]>
  addRoundResult: (round: number, result: RoundResult) => void
  resetGame: () => void
}

const defaultPlayers: Players = {
  player1: {
    name: "",
    avatar: "",
    score: 0,
    roundsWon: 0,
  },
  player2: {
    name: "",
    avatar: "",
    score: 0,
    roundsWon: 0,
  },
}

const defaultGameResults: GameResults = {
  player1Score: 0,
  player2Score: 0,
  player1RoundsWon: 0,
  player2RoundsWon: 0,
  winner: null,
  rounds: {},
}

const GameContext = createContext<GameContextType>({
  players: defaultPlayers,
  setPlayers: () => {},
  currentPlayer: "player1",
  setCurrentPlayer: () => {},
  updateScore: () => {},
  updateRoundsWon: () => {},
  gameResults: defaultGameResults,
  setGameResults: () => {},
  roundResults: {},
  addRoundResult: () => {},
  resetGame: () => {},
})

export function GameProvider({ children }: { children: ReactNode }) {
  const [players, setPlayers] = useState<Players>(defaultPlayers)
  const [currentPlayer, setCurrentPlayer] = useState<"player1" | "player2">("player1")
  const [gameResults, setGameResults] = useState<GameResults>(defaultGameResults)
  const [roundResults, setRoundResults] = useState<Record<number, RoundResult[]>>({})

  const updateScore = (player: "player1" | "player2", points: number) => {
    setPlayers((prev) => ({
      ...prev,
      [player]: {
        ...prev[player],
        score: prev[player].score + points,
      },
    }))
  }

  const updateRoundsWon = (player: "player1" | "player2") => {
    setPlayers((prev) => ({
      ...prev,
      [player]: {
        ...prev[player],
        roundsWon: prev[player].roundsWon + 1,
      },
    }))
  }

  const addRoundResult = (round: number, result: RoundResult) => {
    // Ensure we're not updating during render by using the functional form of setState
    setRoundResults((prev) => {
      // Create a new object to avoid mutating the previous state
      const newResults = { ...prev }
      // Initialize the round array if it doesn't exist
      if (!newResults[round]) {
        newResults[round] = []
      }
      // Add the new result
      newResults[round] = [...newResults[round], result]
      return newResults
    })
  }

  const resetGame = () => {
    setPlayers((prev) => ({
      player1: {
        ...prev.player1,
        score: 0,
        roundsWon: 0,
      },
      player2: {
        ...prev.player2,
        score: 0,
        roundsWon: 0,
      },
    }))
    setCurrentPlayer("player1")
    setGameResults(defaultGameResults)
    setRoundResults({})
  }

  return (
    <GameContext.Provider
      value={{
        players,
        setPlayers,
        currentPlayer,
        setCurrentPlayer,
        updateScore,
        updateRoundsWon,
        gameResults,
        setGameResults,
        roundResults,
        addRoundResult,
        resetGame,
      }}
    >
      {children}
    </GameContext.Provider>
  )
}

export const useGame = () => useContext(GameContext)

