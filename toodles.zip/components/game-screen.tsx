"use client"

import { useState, useEffect, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { useGame } from "@/context/game-context"
import { useSound } from "@/hooks/use-sound"
import { getRandomQuestionPairs, shuffleAnswers } from "@/utils/question-utils"
import BananaTimer from "@/components/banana-timer"
import ConfettiExplosion from "react-confetti-explosion"
import type { RoundResult } from "@/types/game-types"
import PlayerTransition from "@/components/player-transition"
import CountdownScreen from "@/components/countdown-screen"
import { questions } from "@/data/questions"

interface GameScreenProps {
  onFinish: () => void
}

export default function GameScreen({ onFinish }: GameScreenProps) {
  const {
    players,
    currentPlayer,
    setCurrentPlayer,
    updateScore,
    updateRoundsWon,
    setGameResults,
    roundResults,
    addRoundResult,
  } = useGame()

  const { playSound } = useSound()
  const [questionPairs, setQuestionPairs] = useState(() => {
    const pairs = getRandomQuestionPairs(5)
    // Ensure we have at least one pair and all questions have difficulty
    return pairs.length > 0 ? pairs.map(pair => [
      { ...pair[0], difficulty: pair[0]?.difficulty || 'medium' },
      { ...pair[1], difficulty: pair[1]?.difficulty || 'medium' }
    ]) : [[
      { ...questions[0], difficulty: 'medium' },
      { ...questions[1], difficulty: 'medium' }
    ]];
  })
  const [currentRound, setCurrentRound] = useState(1)
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [shuffledOptions, setShuffledOptions] = useState(() => {
    if (questionPairs.length === 0 || !questionPairs[0]) {
      return []
    }
    const playerIndex = currentPlayer === "player1" ? 0 : 1
    const question = questionPairs[0][playerIndex]
    return question ? shuffleAnswers(question) : []
  })

  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null)
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null)
  const [showResult, setShowResult] = useState(false)
  const [timeLeft, setTimeLeft] = useState(0)
  const [isExploding, setIsExploding] = useState(false)
  const [showPlayerTransition, setShowPlayerTransition] = useState(true)
  const [showCountdown, setShowCountdown] = useState(false)
  const [showRoundSummary, setShowRoundSummary] = useState(false)
  const [gameOver, setGameOver] = useState(false)
  const timerRef = useRef<NodeJS.Timeout | null>(null)
  const [timeExpired, setTimeExpired] = useState(false)

  const currentQuestion = questionPairs[currentQuestionIndex]?.[currentPlayer === "player1" ? 0 : 1] || {
    ...questions[0],
    difficulty: "medium"
  }

  // Set timer based on question difficulty
  useEffect(() => {
    if (!showPlayerTransition && !showCountdown && currentQuestion) {
      const difficulty = currentQuestion.difficulty || "medium"
      let maxTime = 30 // default medium difficulty

      if (difficulty === "easy") maxTime = 20
      if (difficulty === "hard") maxTime = 45

      setTimeLeft(maxTime)
      setTimeExpired(false)
    }
  }, [currentQuestion, showPlayerTransition, showCountdown])

  const [milliseconds, setMilliseconds] = useState(0)

  // Start timer when countdown is finished
  useEffect(() => {
    let timerId: NodeJS.Timeout | null = null
    let msTimerId: NodeJS.Timeout | null = null

    if (!showPlayerTransition && !showCountdown && !showResult && !showRoundSummary && !selectedAnswer) {
      const startTime = Date.now()
      const initialTimeLeft = currentQuestion.difficulty === "easy" ? 20 : currentQuestion.difficulty === "hard" ? 45 : 30

      // Main timer for both seconds and milliseconds
      timerId = setInterval(() => {
        const elapsedTime = (Date.now() - startTime) / 1000
        const newTimeLeft = Math.max(0, initialTimeLeft - elapsedTime)

        if (newTimeLeft <= 0) {
          if (timerId) clearInterval(timerId)
          if (msTimerId) clearInterval(msTimerId)
          setTimeLeft(0)
          setMilliseconds(0)
          // Use setTimeout to ensure handleTimeUp is called outside render cycle
          setTimeout(() => handleTimeUp(), 0)
        } else {
          setTimeLeft(Math.floor(newTimeLeft))
          setMilliseconds(Math.floor((newTimeLeft % 1) * 1000))
        }
      }, 10) // Update every 10ms for smooth countdown

      timerRef.current = timerId
    }

    return () => {
      if (timerId) clearInterval(timerId)
      if (msTimerId) clearInterval(msTimerId)
      if (timerRef.current) clearInterval(timerRef.current)
    }
  }, [showPlayerTransition, showCountdown, showResult, showRoundSummary, selectedAnswer])

  // Update handleSubmit to include milliseconds
  const handleSubmit = () => {
    if (!selectedAnswer) return

    // Stop the timer if it's still running
    if (timerRef.current) {
      clearInterval(timerRef.current)
      timerRef.current = null
    }

    const timeTaken = currentQuestion.difficulty === "easy" ? 20 : currentQuestion.difficulty === "hard" ? 45 : 30
    const timeRemaining = timeLeft + (milliseconds / 1000)
    const isAnswerCorrect = selectedAnswer === currentQuestion.correctAnswer

    setIsCorrect(isAnswerCorrect)
    setShowResult(true)

    if (isAnswerCorrect) {
      playSound("chaching", { volume: 0.6 })
      setTimeout(() => playSound("cheer", { volume: 0.4 }), 300)
      setIsExploding(true)
      // Calculate score based on time remaining (more time = more points)
      const scoreToAdd = Math.max(10, Math.floor(timeRemaining * 2))
      updateScore(currentPlayer, scoreToAdd)
    } else {
      playSound("fart", { volume: 0.5 })
      setTimeout(() => playSound("trombone", { volume: 0.6 }), 200)
    }

    // Store the player's result for this round with millisecond precision
    const playerResult = {
      player: currentPlayer,
      isCorrect: isAnswerCorrect,
      timeTaken: timeTaken - timeRemaining,
      timeRemaining: timeRemaining,
      answer: selectedAnswer,
      correctAnswer: currentQuestion.correctAnswer,
      question: currentQuestion.question
    }

    // Add to round results
    addRoundResult(currentRound, playerResult)
  }

  const handleTimeUp = () => {
    if (timeExpired) return // Prevent multiple executions

    setTimeExpired(true)
    playSound("whistle", { volume: 0.7 })
    playSound("slip", { volume: 0.6 })

    // Set as incorrect answer for current player only
    setIsCorrect(false)
    setShowResult(true)

    // Use setTimeout to move state updates out of the render phase
    setTimeout(() => {
      // Store only the current player's result as incorrect due to timeout
      const timeTaken = currentQuestion.difficulty === "easy" ? 20 : currentQuestion.difficulty === "hard" ? 45 : 30

      const playerResult = {
        player: currentPlayer,
        isCorrect: false,
        timeTaken: timeTaken,
        timeRemaining: 0,
        answer: "Time Expired",
        correctAnswer: currentQuestion.correctAnswer,
        question: currentQuestion.question
      }

      // Add only the current player's result
      addRoundResult(currentRound, playerResult)

      // Play failure sounds
      playSound("fart", { volume: 0.5 })
      playSound("trombone", { volume: 0.6 })

      // Switch to the next player or show round summary
      if (roundResults[currentRound]?.length === 1) {
        handleNextPlayer()
      } else {
        handleRoundEnd()
      }
    }, 0)
  }

  const handleAnswerSelect = (answer: string) => {
    if (showResult) return // Only prevent selection if the result is showing
    playSound("pop", { volume: 0.4, rate: 1.2 }) // Add click sound for answer selection
    setSelectedAnswer(answer) // Allow changing the answer
  }

  // Update BananaTimer component call
  <BananaTimer
    timeLeft={timeLeft}
    totalTime={currentQuestion.difficulty === "easy" ? 20 : currentQuestion.difficulty === "hard" ? 45 : 30}
    difficulty={currentQuestion.difficulty || "medium"}
    milliseconds={milliseconds}
  />

  const handleStartRound = () => {
    setShowPlayerTransition(false)
    setShowCountdown(true)
  }

  const handleCountdownComplete = () => {
    setShowCountdown(false)
  }

  const handleNextStep = () => {
    // If both players have answered the current round question
    if (roundResults[currentRound]?.length === 2) {
      // Show round summary
      setShowRoundSummary(true)

      // Determine round winner
      const player1Result = roundResults[currentRound].find((r) => r.player === "player1")
      const player2Result = roundResults[currentRound].find((r) => r.player === "player2")

      if (player1Result && player2Result) {
        let roundWinner: "player1" | "player2" | "tie" = "tie"

        // If both correct, faster player wins
        if (player1Result.isCorrect && player2Result.isCorrect) {
          roundWinner = player1Result.timeRemaining > player2Result.timeRemaining ? "player1" : "player2"
        }
        // If only one correct, they win
        else if (player1Result.isCorrect) {
          roundWinner = "player1"
        } else if (player2Result.isCorrect) {
          roundWinner = "player2"
        }

        // Update rounds won if not a tie
        if (roundWinner !== "tie") {
          updateRoundsWon(roundWinner)
        }

        // Check if game is over (someone has won 3 rounds)
        if (players.player1.roundsWon >= 3 || players.player2.roundsWon >= 3) {
          // Play victory sounds
          playSound("airhorn", { volume: 0.7 })
          setTimeout(() => playSound("cheer", { volume: 0.6 }), 300)

          // Show game over screen and transition to results after a delay
          setGameOver(true)
          setTimeout(() => {
            // Show game over screen with View Results button
            setGameOver(true)
          }, 2000)
        }
      }
    }
    // If only one player has answered, switch to the other player
    else {
      // Switch players
      setShowPlayerTransition(true)
      setCurrentPlayer(currentPlayer === "player1" ? "player2" : "player1")
      setSelectedAnswer(null)
      setIsCorrect(null)
      setShowResult(false)
      setTimeLeft(0)
      setTimeExpired(false)

      // Update shuffled options for the next player - add safety check here
      const nextPlayer = currentPlayer === "player1" ? "player2" : "player1"
      const playerIndex = nextPlayer === "player1" ? 0 : 1

      if (questionPairs[currentQuestionIndex] && questionPairs[currentQuestionIndex][playerIndex]) {
        const question = questionPairs[currentQuestionIndex][playerIndex]
        setShuffledOptions(shuffleAnswers(question))
      }
    }
  }

  // Update the handleNextRound function to maintain player alternation regardless of round
  const handleNextRound = () => {
    // Move to next round
    const nextRound = currentRound + 1
    const nextQuestionIndex = currentQuestionIndex + 1

    setCurrentRound(nextRound)
    setCurrentQuestionIndex(nextQuestionIndex)

    // Always alternate players regardless of round number
    // If current player is player1, next should be player2 and vice versa
    const nextPlayer = currentPlayer === "player1" ? "player2" : "player1"
    setCurrentPlayer(nextPlayer)

    // Update shuffled options for the next question - add safety check
    const playerIndex = nextPlayer === "player1" ? 0 : 1

    if (questionPairs[nextQuestionIndex] && questionPairs[nextQuestionIndex][playerIndex]) {
      const question = questionPairs[nextQuestionIndex][playerIndex]
      setShuffledOptions(shuffleAnswers(question))
    }

    setSelectedAnswer(null)
    setIsCorrect(null)
    setShowResult(false)
    setTimeLeft(0)
    setTimeExpired(false)
    setShowRoundSummary(false)
    setShowPlayerTransition(true)
  }

  const getAvatarEmoji = (avatarId: string) => {
    switch (avatarId) {
      case "taco":
        return "🌮"
      case "pineapple":
        return "🍍"
      case "wizard":
        return "🧙"
      case "pencil":
        return "✏️"
      default:
        return "👽"
    }
  }

  // Calculate player card sizes based on scores
  const getPlayerCardSizes = () => {
    const player1Score = Math.max(1, players.player1.score)
    const player2Score = Math.max(1, players.player2.score)
    const totalScore = player1Score + player2Score

    // Minimum size is 30%, maximum is 70%
    const player1Size = Math.min(70, Math.max(30, Math.round((player1Score / totalScore) * 100)))
    const player2Size = 100 - player1Size

    return { player1Size, player2Size }
  }

  const { player1Size, player2Size } = getPlayerCardSizes()

  // Rainbow border style
  const rainbowBorderStyle = {
    borderImage: "linear-gradient(45deg, #ff0080, #ff8c00, #ffed00, #00ff80, #00bfff, #8a2be2) 1",
    borderImageSlice: 1,
  }

  return (
    <>
      {/* Player Transition Screen */}
      <AnimatePresence>
        {showPlayerTransition && <PlayerTransition player={players[currentPlayer]} onStart={handleStartRound} />}
      </AnimatePresence>

      {/* Countdown Screen */}
      <AnimatePresence>{showCountdown && <CountdownScreen onComplete={handleCountdownComplete} />}</AnimatePresence>

      {/* Main Game Screen */}
      {!showPlayerTransition && !showCountdown && (
        <div className="container mx-auto flex min-h-screen flex-col p-4">
          {/* Round indicator */}
          <motion.div className="mb-4 text-center" initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
            <span className="inline-block rounded-full bg-gradient-to-r from-pink-500 to-orange-500 px-4 py-1 text-lg font-bold text-white shadow-md">
              Round {currentRound}
            </span>
          </motion.div>

          {/* Player info */}
          <div className="mb-6 flex justify-between">
            <motion.div
              className={`rounded-lg bg-white p-3 shadow-lg transition-all duration-300 ${
                currentPlayer === "player1" ? "border-2" : "border border-transparent"
              }`}
              initial={{ x: -50, opacity: 0 }}
              animate={{
                x: 0,
                opacity: 1,
                boxShadow:
                  currentPlayer === "player1"
                    ? "0 0 15px rgba(236,72,153,0.5), 0 0 25px rgba(138,43,226,0.3), 0 0 35px rgba(0,191,255,0.2)"
                    : "0 0 0 rgba(0,0,0,0.1)",
                width: `${player1Size}%`,
              }}
              style={{
                minWidth: "120px",
                ...(currentPlayer === "player1" ? rainbowBorderStyle : {}),
              }}
            >
              <div className="flex items-center gap-2">
                <span className="text-3xl">{getAvatarEmoji(players.player1.avatar)}</span>
                <div>
                  <p className="font-bold text-gray-800">{players.player1.name}</p>
                  <div className="flex items-center gap-2">
                    <p className="text-sm text-gray-600">Score: {players.player1.score}</p>
                    <p className="rounded-full bg-pink-100 px-2 py-0.5 text-xs font-bold text-pink-800">
                      {players.player1.roundsWon} rounds won
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>

            <motion.div
              className={`rounded-lg bg-white p-3 shadow-lg transition-all duration-300 ${
                currentPlayer === "player2" ? "border-2" : "border border-transparent"
              }`}
              initial={{ x: 50, opacity: 0 }}
              animate={{
                x: 0,
                opacity: 1,
                boxShadow:
                  currentPlayer === "player2"
                    ? "0 0 15px rgba(249,115,22,0.5), 0 0 25px rgba(138,43,226,0.3), 0 0 35px rgba(0,191,255,0.2)"
                    : "0 0 0 rgba(0,0,0,0.1)",
                width: `${player2Size}%`,
              }}
              style={{
                minWidth: "120px",
                ...(currentPlayer === "player2" ? rainbowBorderStyle : {}),
              }}
            >
              <div className="flex items-center gap-2 justify-end">
                <div className="text-right">
                  <p className="font-bold text-gray-800">{players.player2.name}</p>
                  <div className="flex items-center justify-end gap-2">
                    <p className="rounded-full bg-orange-100 px-2 py-0.5 text-xs font-bold text-orange-800">
                      {players.player2.roundsWon} rounds won
                    </p>
                    <p className="text-sm text-gray-600">Score: {players.player2.score}</p>
                  </div>
                </div>
                <span className="text-3xl">{getAvatarEmoji(players.player2.avatar)}</span>
              </div>
            </motion.div>
          </div>

          {/* Timer */}
          <div className="mb-4">
            <BananaTimer
              timeLeft={timeLeft}
              totalTime={currentQuestion.difficulty === "easy" ? 20 : currentQuestion.difficulty === "hard" ? 45 : 30}
              difficulty={currentQuestion.difficulty || "medium"}
            />
          </div>

          {/* Question */}
          <AnimatePresence mode="wait">
            {!gameOver && !showRoundSummary && (
              <motion.div
                key={`question-${currentQuestionIndex}-${currentPlayer}`}
                className="relative mb-8 rounded-xl bg-white p-6 shadow-lg border-2"
                initial={{ opacity: 0, y: 20, rotate: -2 }}
                animate={{ opacity: 1, y: 0, rotate: 0 }}
                exit={{ opacity: 0, y: -20, rotate: 2 }}
                transition={{ duration: 0.5 }}
                style={{
                  boxShadow:
                    "0 0 10px rgba(255,0,128,0.3), 0 0 20px rgba(138,43,226,0.2), 0 0 30px rgba(0,191,255,0.1)",
                  ...rainbowBorderStyle,
                }}
              >
                {/* Math tornado background */}
                <div className="absolute inset-0 overflow-hidden rounded-xl opacity-10">
                  <motion.div
                    className="absolute inset-0"
                    style={{
                      backgroundImage: "url('/placeholder.svg?height=400&width=400')",
                      backgroundSize: "cover",
                    }}
                    animate={{ rotate: 360 }}
                    transition={{ duration: 20, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                  />
                </div>

                <div className="relative z-10">
                  <div className="mb-2 flex justify-between">
                    <span className="inline-block rounded-full bg-gradient-to-r from-pink-500 to-purple-500 px-3 py-1 text-xs font-medium text-white">
                      Difficulty: {currentQuestion.difficulty || "Medium"}
                    </span>
                  </div>

                  <h2 className="mb-6 text-center text-2xl font-bold text-gray-800">{currentQuestion.question}</h2>

                  <div className="grid gap-4 md:grid-cols-2">
                    {shuffledOptions.map((option, index) => (
                      <motion.button
                        key={index}
                        className={`flex items-center justify-between rounded-lg border-2 p-4 text-left transition-all ${
                          selectedAnswer === option.text ? "bg-pink-50" : "hover:border-pink-300"
                        } ${
                          showResult
                            ? option.text === currentQuestion.correctAnswer
                              ? "bg-green-50"
                              : selectedAnswer === option.text
                                ? "bg-red-50"
                                : ""
                            : ""
                        }`}
                        onClick={() => handleAnswerSelect(option.text)}
                        disabled={showResult}
                        whileHover={{ scale: showResult ? 1 : 1.02 }}
                        whileTap={{ scale: showResult ? 1 : 0.98 }}
                        animate={
                          showResult && option.text === currentQuestion.correctAnswer
                            ? {
                                boxShadow: [
                                  "0 0 0 rgba(0,255,0,0)",
                                  "0 0 20px rgba(0,255,0,0.7)",
                                  "0 0 0 rgba(0,255,0,0)",
                                ],
                              }
                            : {}
                        }
                        transition={
                          showResult && option.text === currentQuestion.correctAnswer
                            ? { repeat: Number.POSITIVE_INFINITY, duration: 1.5 }
                            : {}
                        }
                        style={
                          selectedAnswer === option.text
                            ? { ...rainbowBorderStyle }
                            : showResult && option.text === currentQuestion.correctAnswer
                              ? { borderImage: "linear-gradient(45deg, #22c55e, #16a34a) 1", borderImageSlice: 1 }
                              : showResult && selectedAnswer === option.text
                                ? { borderImage: "linear-gradient(45deg, #ef4444, #dc2626) 1", borderImageSlice: 1 }
                                : {}
                        }
                      >
                        <span>
                          <span className="mr-2 inline-block h-6 w-6 rounded-full bg-pink-100 text-center font-medium text-pink-800">
                            {String.fromCharCode(97 + index)}
                          </span>
                          {option.text}
                        </span>
                        {showResult && option.text === currentQuestion.correctAnswer && (
                          <motion.span initial={{ scale: 0 }} animate={{ scale: 1 }} className="text-xl text-green-500">
                            ✓
                          </motion.span>
                        )}
                        {showResult &&
                          option.text === selectedAnswer &&
                          option.text !== currentQuestion.correctAnswer && (
                            <motion.span initial={{ scale: 0 }} animate={{ scale: 1 }} className="text-xl text-red-500">
                              ✗
                            </motion.span>
                          )}
                      </motion.button>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Submit button */}
          {!showResult && !gameOver && !showRoundSummary && (
            <motion.div
              className="flex justify-center"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              <Button
                onClick={handleSubmit}
                disabled={!selectedAnswer}
                className="relative overflow-hidden px-8 py-4 text-xl font-bold text-white shadow-lg transition-all hover:scale-105 hover:shadow-xl disabled:opacity-50"
                style={{
                  background: "linear-gradient(to right, #ff0080, #ff8c00, #ffed00, #00ff80, #00bfff, #8a2be2)",
                  backgroundSize: "200% auto",
                  boxShadow: selectedAnswer ? "0 0 5px rgba(236,72,153,0.5), 0 0 10px rgba(249,115,22,0.5)" : "none",
                }}
              >
                Submit Answer
                <motion.div
                  className="absolute inset-0 -z-10"
                  animate={{
                    backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"],
                  }}
                  transition={{
                    duration: 3,
                    ease: "linear",
                    repeat: Number.POSITIVE_INFINITY,
                  }}
                  style={{
                    background: "linear-gradient(to right, #ff0080, #ff8c00, #ffed00, #00ff80, #00bfff, #8a2be2)",
                    backgroundSize: "200% auto",
                  }}
                />
              </Button>
            </motion.div>
          )}

          {/* Result message */}
          <AnimatePresence>
            {showResult && !gameOver && !showRoundSummary && (
              <motion.div
                className="mt-6 flex flex-col items-center justify-center"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
              >
                {isCorrect ? (
                  <>
                    {isExploding && <ConfettiExplosion force={0.8} duration={3000} particleCount={100} width={1600} />}
                    <motion.div
                      className="mb-4 rounded-lg bg-green-100 p-4 text-center text-xl font-bold text-green-800 border-2"
                      animate={{
                        scale: [1, 1.1, 1],
                      }}
                      transition={{ repeat: 2, duration: 0.5 }}
                      style={rainbowBorderStyle}
                    >
                      Nailed it! 🎯 Time remaining: {timeLeft}s
                    </motion.div>
                  </>
                ) : timeExpired ? (
                  <motion.div
                    className="mb-4 rounded-lg bg-red-100 p-4 text-center text-xl font-bold text-red-800 border-2"
                    animate={{
                      rotate: [0, -2, 2, -2, 0],
                    }}
                    transition={{ repeat: 2, duration: 0.5 }}
                    style={rainbowBorderStyle}
                  >
                    TIME'S UP! 💥 The vial has emptied!
                  </motion.div>
                ) : (
                  <motion.div
                    className="mb-4 rounded-lg bg-red-100 p-4 text-center text-xl font-bold text-red-800 border-2"
                    animate={{
                      rotate: [0, -2, 2, -2, 0],
                    }}
                    transition={{ repeat: 2, duration: 0.5 }}
                    style={rainbowBorderStyle}
                  >
                    Uh-oh, SAT-astrophe! 💩 Time remaining: {timeLeft}s
                  </motion.div>
                )}
                <Button
                  onClick={handleNextStep}
                  className="relative overflow-hidden px-8 py-4 text-xl font-bold text-white shadow-lg transition-all hover:scale-105 hover:shadow-xl"
                  style={{
                    background: "linear-gradient(to right, #ff0080, #ff8c00, #ffed00, #00ff80, #00bfff, #8a2be2)",
                    backgroundSize: "200% auto",
                    boxShadow: "0 0 5px rgba(236,72,153,0.5), 0 0 10px rgba(249,115,22,0.5)",
                  }}
                >
                  {roundResults[currentRound]?.length === 1 ? "Next Player" : "See Round Results"}
                  <motion.div
                    className="absolute inset-0 -z-10"
                    animate={{
                      backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"],
                    }}
                    transition={{
                      duration: 3,
                      ease: "linear",
                      repeat: Number.POSITIVE_INFINITY,
                    }}
                    style={{
                      background: "linear-gradient(to right, #ff0080, #ff8c00, #ffed00, #00ff80, #00bfff, #8a2be2)",
                      backgroundSize: "200% auto",
                    }}
                  />
                </Button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Round Summary */}
          <AnimatePresence>
            {showRoundSummary && (
              <motion.div
                className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-70"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                <motion.div
                  className="w-full max-w-2xl rounded-xl bg-white p-8 shadow-2xl border-2"
                  initial={{ scale: 0.8, y: 50 }}
                  animate={{ scale: 1, y: 0 }}
                  exit={{ scale: 0.8, y: 50 }}
                  style={rainbowBorderStyle}
                >
                  <h2 className="mb-6 text-center text-3xl font-bold text-gray-800">Round {currentRound} Results</h2>

                  <div className="mb-8 grid gap-6 md:grid-cols-2">
                    {roundResults[currentRound]?.map((result: RoundResult, index: number) => {
                      const player = players[result.player]
                      return (
                        <div
                          key={index}
                          className={`rounded-lg p-4 border-2 ${result.isCorrect ? "bg-green-50" : "bg-red-50"}`}
                          style={rainbowBorderStyle}
                        >
                          <div className="flex items-center gap-3">
                            <span className="text-3xl">{getAvatarEmoji(player.avatar)}</span>
                            <div>
                              <p className="font-bold text-gray-800">{player.name}</p>
                              <p className="text-sm text-gray-600">
                                {result.answer === "Time Expired"
                                  ? "Time Expired!"
                                  : `Time remaining: ${result.timeRemaining}s`}
                              </p>
                              <p className={`mt-1 font-medium ${result.isCorrect ? "text-green-600" : "text-red-600"}`}>
                                {result.isCorrect ? "Correct ✓" : "Incorrect ✗"}
                              </p>
                            </div>
                          </div>
                        </div>
                      )
                    })}
                  </div>

                  {/* Round winner */}
                  <div className="mb-6 text-center">
                    {(() => {
                      const player1Result = roundResults[currentRound]?.find((r) => r.player === "player1")
                      const player2Result = roundResults[currentRound]?.find((r) => r.player === "player2")

                      if (player1Result && player2Result) {
                        // Both correct, faster wins
                        if (player1Result.isCorrect && player2Result.isCorrect) {
                          const winner =
                            player1Result.timeRemaining > player2Result.timeRemaining ? "player1" : "player2"
                          return (
                            <motion.div
                              className="rounded-lg bg-pink-100 p-3 text-xl font-bold text-pink-800 border-2"
                              animate={{ scale: [1, 1.05, 1] }}
                              transition={{ repeat: 2, duration: 0.5 }}
                              style={rainbowBorderStyle}
                            >
                              {players[winner].name} wins the round by being faster!
                            </motion.div>
                          )
                        }
                        // Only one correct
                        else if (player1Result.isCorrect) {
                          return (
                            <motion.div
                              className="rounded-lg bg-pink-100 p-3 text-xl font-bold text-pink-800 border-2"
                              animate={{ scale: [1, 1.05, 1] }}
                              transition={{ repeat: 2, duration: 0.5 }}
                              style={rainbowBorderStyle}
                            >
                              {players.player1.name} wins the round with the correct answer!
                            </motion.div>
                          )
                        } else if (player2Result.isCorrect) {
                          return (
                            <motion.div
                              className="rounded-lg bg-pink-100 p-3 text-xl font-bold text-pink-800 border-2"
                              animate={{ scale: [1, 1.05, 1] }}
                              transition={{ repeat: 2, duration: 0.5 }}
                              style={rainbowBorderStyle}
                            >
                              {players.player2.name} wins the round with the correct answer!
                            </motion.div>
                          )
                        }
                        // Both wrong
                        else {
                          return (
                            <div
                              className="rounded-lg bg-gray-100 p-3 text-xl font-bold text-gray-800 border-2"
                              style={rainbowBorderStyle}
                            >
                              It's a tie! Both players answered incorrectly.
                            </div>
                          )
                        }
                      }
                      return null
                    })()}
                  </div>

                  {/* Game status */}
                  <div className="mb-8 flex justify-center gap-8">
                    <div className="text-center">
                      <p className="text-lg font-bold text-pink-600">{players.player1.name}</p>
                      <p className="text-3xl font-bold">{players.player1.roundsWon}</p>
                      <p className="text-sm text-gray-600">rounds won</p>
                    </div>
                    <div className="text-center">
                      <p className="text-lg font-bold text-orange-600">{players.player2.name}</p>
                      <p className="text-3xl font-bold">{players.player2.roundsWon}</p>
                      <p className="text-sm text-gray-600">rounds won</p>
                    </div>
                  </div>

                  {/* Next round button */}
                  {players.player1.roundsWon < 3 && players.player2.roundsWon < 3 ? (
                    <div className="flex justify-center">
                      <Button
                        onClick={handleNextRound}
                        className="relative overflow-hidden px-8 py-4 text-xl font-bold text-white shadow-lg transition-all hover:scale-105 hover:shadow-xl"
                        style={{
                          background: "linear-gradient(to right, #ff0080, #ff8c00, #ffed00, #00ff80, #00bfff, #8a2be2)",
                          backgroundSize: "200% auto",
                        }}
                      >
                        Next Round
                        <motion.div
                          className="absolute inset-0 -z-10"
                          animate={{
                            backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"],
                          }}
                          transition={{
                            duration: 3,
                            ease: "linear",
                            repeat: Number.POSITIVE_INFINITY,
                          }}
                          style={{
                            background:
                              "linear-gradient(to right, #ff0080, #ff8c00, #ffed00, #00ff80, #00bfff, #8a2be2)",
                            backgroundSize: "200% auto",
                          }}
                        />
                      </Button>
                    </div>
                  ) : (
                    <div className="flex justify-center">
                      <Button
                        onClick={() => {
                          // Set final game results
                          setGameResults({
                            player1Score: players.player1.score,
                            player2Score: players.player2.score,
                            player1RoundsWon: players.player1.roundsWon,
                            player2RoundsWon: players.player2.roundsWon,
                            winner: players.player1.roundsWon > players.player2.roundsWon ? "player1" : "player2",
                            rounds: roundResults,
                          });
                          // Transition to results screen
                          onFinish();
                        }}
                        className="relative overflow-hidden px-8 py-4 text-xl font-bold text-white shadow-lg transition-all hover:scale-105 hover:shadow-xl"
                        style={{
                          background: "linear-gradient(to right, #ff0080, #ff8c00, #ffed00, #00ff80, #00bfff, #8a2be2)",
                          backgroundSize: "200% auto",
                        }}
                      >
                        View Final Results
                        <motion.div
                          className="absolute inset-0 -z-10"
                          animate={{
                            backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"],
                          }}
                          transition={{
                            duration: 3,
                            ease: "linear",
                            repeat: Number.POSITIVE_INFINITY,
                          }}
                          style={{
                            background:
                              "linear-gradient(to right, #ff0080, #ff8c00, #ffed00, #00ff80, #00bfff, #8a2be2)",
                            backgroundSize: "200% auto",
                          }}
                        />
                      </Button>
                    </div>
                  )}
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      )}
    </>
  )
}

