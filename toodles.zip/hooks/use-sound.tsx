"use client"

import { useEffect, useRef } from "react"
import { Howl } from "howler"
import { SOUND_URLS, type SoundType } from "@/data/sounds"

// Add global background music instance tracking
let globalBackgroundMusic: Howl | null = null

export function useSound() {
  const soundsRef = useRef<Record<SoundType, Howl | null>>({} as Record<SoundType, Howl | null>)
  const backgroundMusicRef = useRef<Howl | null>(null)

  useEffect(() => {
    // Initialize sounds
    Object.entries(SOUND_URLS).forEach(([key, url]) => {
      const isBackgroundMusic = key === "backgroundMusic"

      // Skip creating new background music instance if it already exists globally
      if (isBackgroundMusic && globalBackgroundMusic) {
        soundsRef.current[key as SoundType] = globalBackgroundMusic
        backgroundMusicRef.current = globalBackgroundMusic
        return
      }

      // Only create new Howl instance if it doesn't exist
      if (!soundsRef.current[key as SoundType]) {
        const sound = new Howl({
          src: [url],
          volume: isBackgroundMusic ? 0.3 : 0.5,
          html5: true,
          loop: isBackgroundMusic,
          autoplay: false,
          preload: true,
        })

        soundsRef.current[key as SoundType] = sound

        // Store background music globally if it's the first instance
        if (isBackgroundMusic && !globalBackgroundMusic) {
          globalBackgroundMusic = sound
          backgroundMusicRef.current = sound
          sound.play()
        }
      }
    })

    return () => {
      // Only cleanup non-background music sounds
      Object.entries(soundsRef.current).forEach(([key, sound]) => {
        if (sound && key !== "backgroundMusic") {
          sound.stop()
          sound.unload()
          delete soundsRef.current[key as SoundType]
        }
      })
    }
  }, [])

  const playSound = (type: SoundType, options?: { rate?: number; volume?: number }) => {
    const sound = soundsRef.current[type]
    if (sound) {
      // Stop any existing instances of the same sound (except background music)
      if (type !== "backgroundMusic") {
        sound.stop()
      }

      if (options?.rate) sound.rate(options.rate)
      if (options?.volume) sound.volume(options.volume)

      if (type === "airhorn") {
        // Play airhorn twice with a slight delay for longer effect
        sound.play()
        setTimeout(() => sound.play(), 300)
      } else if (type === "countdown" || type === "timerCountDownBeep") {
        // Only play countdown sounds when explicitly called
        const id = sound.play()
        // Stop the sound after it's done playing to prevent memory leaks
        sound.once("end", () => {
          sound.stop(id)
        })
      } else if (type !== "backgroundMusic") {
        // Play the sound
        sound.play()
      }
    }
  }

  const stopSound = (type: SoundType) => {
    const sound = soundsRef.current[type]
    if (sound) sound.stop()
  }

  return { playSound, stopSound }
}

