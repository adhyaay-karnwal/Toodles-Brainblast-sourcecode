"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"

interface PlayerTransitionProps {
  player: {
    name: string
    avatar: string
  }
  onStart: () => void
}

export default function PlayerTransition({ player, onStart }: PlayerTransitionProps) {
  const getAvatarEmoji = (avatarId: string) => {
    switch (avatarId) {
      case "taco":
        return "🌮"
      case "pineapple":
        return "🍍"
      case "wizard":
        return "🧙"
      case "pencil":
        return "✏️"
      default:
        return "👽"
    }
  }

  return (
    <motion.div
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-black bg-opacity-80"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <motion.div
        className="mb-8 text-center text-5xl font-extrabold text-white"
        initial={{ scale: 0.5, y: -100 }}
        animate={{ scale: 1, y: 0 }}
        transition={{
          type: "spring",
          stiffness: 200,
          damping: 10,
        }}
      >
        PASS THE DEVICE TO
      </motion.div>

      <motion.div
        className="text-center text-3xl text-white"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
      >
        <div className="mb-4 text-6xl">{getAvatarEmoji(player.avatar)}</div>
        <div className="mb-8 text-4xl font-bold">{player.name}</div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.8 }}>
        <Button
          onClick={onStart}
          className="relative overflow-hidden px-8 py-6 text-xl font-bold text-white shadow-lg transition-all hover:scale-105 hover:shadow-xl"
          style={{
            background: "linear-gradient(to right, #ff0080, #ff8c00, #ffed00, #00ff80, #00bfff, #8a2be2)",
            backgroundSize: "200% auto",
            boxShadow: "0 0 10px rgba(255,0,128,0.5), 0 0 20px rgba(138,43,226,0.3), 0 0 30px rgba(0,191,255,0.2)",
          }}
        >
          START MY ROUND
          <motion.div
            className="absolute inset-0 -z-10"
            animate={{
              backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"],
            }}
            transition={{
              duration: 3,
              ease: "linear",
              repeat: Number.POSITIVE_INFINITY,
            }}
            style={{
              background: "linear-gradient(to right, #ff0080, #ff8c00, #ffed00, #00ff80, #00bfff, #8a2be2)",
              backgroundSize: "200% auto",
            }}
          />
        </Button>
      </motion.div>
    </motion.div>
  )
}

